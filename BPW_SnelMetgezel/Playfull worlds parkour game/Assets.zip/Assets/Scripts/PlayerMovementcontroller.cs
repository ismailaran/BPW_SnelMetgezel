﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovementcontroller : MonoBehaviour
{
    bool canWalk = true;
    bool jumping = false;
    bool canWallJump = false;
    Vector3 walljumpVelocity;
    Vector3 wallJumpNormal;
    public float movespeed;
    public float maxSpeed;
    public float jumpHeight;
    public float wallJumpSpeed;
    public float drag;
    
    Rigidbody rb;

    Vector3 m_EulerAngleVelocity;

    void Start()
    {
        rb = GetComponent<Rigidbody>(); 
    }

    // Update is called once per frame
    void Update()
    {
        //running 
        if (canWalk == true && jumping == false)
        {
            rb.AddForce(transform.forward * Input.GetAxis("Vertical") * movespeed);
            rb.AddForce(transform.right * Input.GetAxis("Horizontal") * movespeed);
        }
        //set maximum speed
        if (rb.velocity.magnitude > maxSpeed)
        {
            rb.velocity = rb.velocity.normalized * maxSpeed;
        }
        //drag modifier
        if (Input.GetKey(KeyCode.LeftControl) == true && jumping == false)
        {
            canWalk = false;
            rb.drag = drag;
        }
        else
        {
            canWalk = true;
            rb.drag = 0;
        }
        
        //rotate camera left/right
        rb.MoveRotation(rb.rotation * Quaternion.Euler(0, Input.GetAxis("Mouse X"), 0));
    }

    void FixedUpdate(){
        //jumping
        if (Input.GetKey(KeyCode.Space) == true)
        {
            if (jumping == false)
            {
                jumping = true;
                rb.AddForce(new Vector3(0, jumpHeight, 0), ForceMode.Impulse);
            }
            else if (canWallJump == true)
            {
                canWallJump = false;
                rb.velocity = Vector3.Normalize (new Vector3(0, 0, walljumpVelocity.z)) * 10 * wallJumpSpeed + new Vector3(0, jumpHeight, 0) + wallJumpNormal * 10 * wallJumpSpeed;
            }
        }

        if (canWallJump == false)
        {
            walljumpVelocity = rb.velocity;
        }

    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "ground")
        {
            jumping = false;
            canWallJump = false;
        }

        if (collision.gameObject.tag == "wall")
        {
            wallJumpNormal = collision.contacts[0].normal;
            canWallJump = true;  
        }
    }

    void OnCollisionExit(Collision collision)
    {
        if (collision.gameObject.tag == "wall")
        {
            canWallJump = false;
        }
    }
}
